ConfigSet
---------

.. automodule:: waflib.ConfigSet

