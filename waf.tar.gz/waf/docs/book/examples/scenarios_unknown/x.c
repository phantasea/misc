int k=3;
