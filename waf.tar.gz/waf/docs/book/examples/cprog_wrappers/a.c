int a = 32;
