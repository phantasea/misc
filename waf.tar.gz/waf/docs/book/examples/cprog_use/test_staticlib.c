int k = 32;
