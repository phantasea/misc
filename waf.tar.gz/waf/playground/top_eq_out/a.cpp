int truc=5;

