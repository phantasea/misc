
use builtin;
use str;

set edit:completion:arg-completer[ouch] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'ouch'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'ouch'= {
            cand -f 'Specify the format of the archive'
            cand --format 'Specify the format of the archive'
            cand -y 'Skip [Y/n] questions positively'
            cand --yes 'Skip [Y/n] questions positively'
            cand -n 'Skip [Y/n] questions negatively'
            cand --no 'Skip [Y/n] questions negatively'
            cand -A 'Activate accessibility mode, reducing visual noise'
            cand --accessible 'Activate accessibility mode, reducing visual noise'
            cand -H 'Ignores hidden files'
            cand --hidden 'Ignores hidden files'
            cand -q 'Silences output'
            cand --quiet 'Silences output'
            cand -g 'Ignores files matched by git''s ignore files'
            cand --gitignore 'Ignores files matched by git''s ignore files'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand -V 'Print version'
            cand --version 'Print version'
            cand compress 'Compress one or more files into one output file'
            cand decompress 'Decompresses one or more files, optionally into another folder'
            cand list 'List contents of an archive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'ouch;compress'= {
            cand -l 'Compression level, applied to all formats'
            cand --level 'Compression level, applied to all formats'
            cand -f 'Specify the format of the archive'
            cand --format 'Specify the format of the archive'
            cand --fast 'Fastest compression level possible, conflicts with --level and --slow'
            cand --slow 'Slowest (and best) compression level possible, conflicts with --level and --fast'
            cand -y 'Skip [Y/n] questions positively'
            cand --yes 'Skip [Y/n] questions positively'
            cand -n 'Skip [Y/n] questions negatively'
            cand --no 'Skip [Y/n] questions negatively'
            cand -A 'Activate accessibility mode, reducing visual noise'
            cand --accessible 'Activate accessibility mode, reducing visual noise'
            cand -H 'Ignores hidden files'
            cand --hidden 'Ignores hidden files'
            cand -q 'Silences output'
            cand --quiet 'Silences output'
            cand -g 'Ignores files matched by git''s ignore files'
            cand --gitignore 'Ignores files matched by git''s ignore files'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'ouch;decompress'= {
            cand -d 'Place results in a directory other than the current one'
            cand --dir 'Place results in a directory other than the current one'
            cand -f 'Specify the format of the archive'
            cand --format 'Specify the format of the archive'
            cand -y 'Skip [Y/n] questions positively'
            cand --yes 'Skip [Y/n] questions positively'
            cand -n 'Skip [Y/n] questions negatively'
            cand --no 'Skip [Y/n] questions negatively'
            cand -A 'Activate accessibility mode, reducing visual noise'
            cand --accessible 'Activate accessibility mode, reducing visual noise'
            cand -H 'Ignores hidden files'
            cand --hidden 'Ignores hidden files'
            cand -q 'Silences output'
            cand --quiet 'Silences output'
            cand -g 'Ignores files matched by git''s ignore files'
            cand --gitignore 'Ignores files matched by git''s ignore files'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'ouch;list'= {
            cand -f 'Specify the format of the archive'
            cand --format 'Specify the format of the archive'
            cand -t 'Show archive contents as a tree'
            cand --tree 'Show archive contents as a tree'
            cand -y 'Skip [Y/n] questions positively'
            cand --yes 'Skip [Y/n] questions positively'
            cand -n 'Skip [Y/n] questions negatively'
            cand --no 'Skip [Y/n] questions negatively'
            cand -A 'Activate accessibility mode, reducing visual noise'
            cand --accessible 'Activate accessibility mode, reducing visual noise'
            cand -H 'Ignores hidden files'
            cand --hidden 'Ignores hidden files'
            cand -q 'Silences output'
            cand --quiet 'Silences output'
            cand -g 'Ignores files matched by git''s ignore files'
            cand --gitignore 'Ignores files matched by git''s ignore files'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'ouch;help'= {
            cand compress 'Compress one or more files into one output file'
            cand decompress 'Decompresses one or more files, optionally into another folder'
            cand list 'List contents of an archive'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'ouch;help;compress'= {
        }
        &'ouch;help;decompress'= {
        }
        &'ouch;help;list'= {
        }
        &'ouch;help;help'= {
        }
    ]
    $completions[$command]
}
